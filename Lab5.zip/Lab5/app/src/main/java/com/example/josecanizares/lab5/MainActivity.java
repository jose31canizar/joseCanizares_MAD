package com.example.josecanizares.lab5;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.SeekBar.OnSeekBarChangeListener;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    String favColor = "";
    String favMood = "";
    int favVolume = -1;
    String favShape = "";
    boolean piano = false;
    boolean guitar = false;
    boolean drums = false;
    boolean Lyrics = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        System.out.println("creating");
        setContentView(R.layout.activity_main);
        Switch switch1 = (Switch) findViewById(R.id.lyricsSwitch);
        switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if (isChecked) {
                Lyrics = false;
            } else {
                Lyrics = true;
            }
            }
        });
        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.colors);
        radioGroup.setOnCheckedChangeListener(new OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton checkedRadioButton = (RadioButton)group.findViewById(checkedId);
                boolean isChecked = checkedRadioButton.isChecked();
                if (isChecked)
                {
                    favColor = checkedRadioButton.getText().toString();
                }
            }
        });
        Spinner spinner = (Spinner) findViewById(R.id.moodSpinner);
        spinner.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                switch(position) {
                    case 0:
                        favMood = "Angry";
                        break;
                    case 1:
                        favMood = "Joyful";
                        break;
                    case 2:
                        favMood = "Melancholy";
                        break;
                    case 3:
                        favMood = "Weird";
                        break;

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {

            }

        });
        SeekBar sk=(SeekBar) findViewById(R.id.volumeSeekBar);
        sk.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                System.out.println(seekBar.getProgress());
                favVolume = seekBar.getProgress();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,boolean fromUser) {

            }
        });
        ToggleButton tg1 = (ToggleButton) findViewById(R.id.shape1);
        ToggleButton tg2 = (ToggleButton) findViewById(R.id.shape2);
        ToggleButton tg3 = (ToggleButton) findViewById(R.id.shape3);
        tg1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                {
                    favShape="square";
                }
            }
        });
        tg2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                {
                    favShape="circle";
                }
            }
        });
        tg3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                {
                    favShape="triangle";
                    System.out.println("triangle");
                }
            }
        });
        CheckBox ch1 = (CheckBox) findViewById(R.id.instrument1);
        CheckBox ch2 = (CheckBox) findViewById(R.id.instrument2);
        CheckBox ch3 = (CheckBox) findViewById(R.id.instrument3);
        ch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
           @Override
           public void onCheckedChanged(CompoundButton buttonView,boolean isChecked) {
                if (isChecked) {
                    piano = true;
                } else {
                    piano = false;
                }
           }
        });
        ch2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView,boolean isChecked) {
                if (isChecked) {
                    guitar = true;
                } else {
                    guitar = false;
                }
            }
        });
        ch3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView,boolean isChecked) {
                if (isChecked) {
                    drums = true;
                } else {
                    drums = false;
                }
            }
        });
    }



    public void discover(View view) {
        System.out.println("INFO:\n");
        System.out.println(favColor);
        System.out.println(favMood);
        System.out.println(favVolume);
        System.out.println(favShape);
        System.out.println(piano);
        System.out.println(guitar);
        System.out.println(drums);
        System.out.println(Lyrics);


        if(favColor.equals("") || favMood.equals("") || favVolume == -1 || favShape.equals("")) {
            Context context = getApplicationContext();
            CharSequence text = "Please fill in all parts of the form.";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        } else {
            TextView res = (TextView) findViewById(R.id.result);
            if(favColor.equals("Blue") && guitar == true && Lyrics == true) {
                res.setText("Jazz blues.");
            } else if (favColor.equals("Red") && favMood.equals("Angry") && piano == false && Lyrics == true && favVolume > 80) {
                res.setText("Heavy metal.");
            } else if (favColor.equals("Yellow") && favMood.equals("Joyful") && piano == true && Lyrics == true) {
                res.setText("Indie folk.");
            } else if (favMood.equals("Weird") && piano == true && drums == true && Lyrics == false) {
                res.setText("Alternative.");
            } else if (favMood.equals("Melancholy") && piano == true && Lyrics == true) {
                res.setText("Soul.");
            } else if (favMood.equals("Joyful") && guitar == true && Lyrics == false && favVolume > 60) {
                res.setText("Funk.");
            } else if (favShape.equals("circle")){
                res.setText("Hip Hop.");
            } else if (favShape.equals("triangle")){
                res.setText("Rap.");
            } else {
                res.setText("R & B.");
            }
        }
    }

}
