package com.example.josecanizares.lab6;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.view.ViewGroup.LayoutParams;
import android.view.View.OnClickListener;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        createTableCell();
    }

    String[] names = {  "Nike Zoom Vaporfly Elite",
            "Yeezy Boost 350 v2 Beluga 2",
            "Fear of God x Era 95 DX",
            "Nike Air Max 97 Metallic Gold",
            "Air Jordan 11 Retro"};

    String[] prices = {
            "$100",
            "$200",
            "$300",
            "$350",
            "$250"
    };

    public void createTableCell(){
        TableLayout layout = (TableLayout) findViewById(R.id.tableLayout);



        for (int i = 0; i <5; i++) {
            TableRow row = new TableRow(this);

            TableRow.LayoutParams params = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
            row.setLayoutParams(params);


            TextView shoeTitle = new TextView(this);
            TextView shoePrice = new TextView(this);
            TextView buyText = new TextView(this);
            LinearLayout description = new LinearLayout(this);
//            LinearLayout.LayoutParams prms = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT);
//            description.setLayoutParams(prms);
            description.setOrientation(LinearLayout.VERTICAL);
            shoeTitle.setTextSize(15);
            Typeface avenir = Typeface.createFromAsset(getAssets(), "avenir.ttf");
            shoeTitle.setTypeface(avenir);
            shoeTitle.setText(names[i]);

            shoePrice.setTextSize(22);
            shoePrice.setText(prices[i]);

            buyText.setText("buy now!");

            description.addView(shoeTitle);
            description.addView(shoePrice);
            description.addView(buyText);
            row.addView(description);

            ImageView shoe = new ImageView(this);

            Display display = getWindowManager().getDefaultDisplay();
            int width = display.getWidth();
            int height = display.getHeight();
            shoe.setImageResource(getImageId(this, "shoe" + (i+1)));
            shoe.setScaleType(ImageView.ScaleType.FIT_END);
            TableRow.LayoutParams layoutParams = new TableRow.LayoutParams(width/3, height/5);
            layoutParams.setMargins(0, 10, 10, 20);
            if(getResources().getConfiguration().orientation == 2) {
                layoutParams.weight = 1.0f;
                layoutParams.gravity = Gravity.RIGHT;
            }
            shoe.setLayoutParams(layoutParams);
            shoe.requestLayout();

            row.addView(shoe);

            row.setBackgroundColor(Color.parseColor("#f1f1f1"));
            row.setPadding(40, 40, 0, 20);

            layout.addView(row, i);

            row.setOnClickListener(new RowOnClickListener(names[i], prices[i], i));
        }
    }

    public static int getImageId(Context context, String imageName) {
        return context.getResources().getIdentifier("drawable/" + imageName, null, context.getPackageName());
    }

    public void goToCart(String name, String price, int i) {
        Intent intent = new Intent(this, ShoppingCartActivity.class);
        intent.putExtra("shoeName", name);
        intent.putExtra("shoePrice", price);
        intent.putExtra("index", i);
        startActivity(intent);
    }

    public class RowOnClickListener implements OnClickListener
    {

        int index;
        String name;
        String price;
        public RowOnClickListener(String name, String price, int index) {
            this.index = index;
            this.name = name;
            this.price = price;
        }



        @Override
        public void onClick(View v)
        {
            goToCart(this.name, this.price, this.index);
            return;
        }

    };



}
