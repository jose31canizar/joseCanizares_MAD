package com.example.josecanizares.lab6;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class ShoppingCartActivity extends AppCompatActivity {

    private String name;
    private String price;
    private int index;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_cart);

        Intent intent = getIntent();
        name = intent.getStringExtra("shoeName");
        price = intent.getStringExtra("shoePrice");
        index = intent.getIntExtra("index", 0);

        TextView nameView = (TextView)findViewById(R.id.shoeName);
        TextView priceView = (TextView)findViewById(R.id.shoePrice);
        ImageView shoe = (ImageView)findViewById(R.id.shoeImage);

        shoe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadWebSite(v);
            }
        });

        nameView.setText(name);
        priceView.setText(price);
        shoe.setImageResource(getImageId(this, "shoe" + (index+1)));
    }

    public void loadWebSite(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("https://www.goat.com/"));
        startActivity(intent);
    }

    public static int getImageId(Context context, String imageName) {
        return context.getResources().getIdentifier("drawable/" + imageName, null, context.getPackageName());
    }
}
