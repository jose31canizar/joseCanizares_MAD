package com.example.josecanizares.josefinal;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Restaurant extends AppCompatActivity {

    String chosen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant);
        setTitle("Burrito");

        TextView suggest = (TextView) findViewById(R.id.suggestion);
        ImageView earth = (ImageView) findViewById(R.id.earth);

        earth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadSite(chosen);
            }
        });

        Intent intent = getIntent();
        String location = intent.getStringExtra("location");


        String chipotle = "https://www.chipotle.com/";
        String petes = "https://www.illegalpetes.com/";
        String bartaco = "https://www.bartaco.com/";

        chosen = "";
        String chosenRestaurant = "";

        if(location.equals("The Hill")) {
            chosen = petes;
            chosenRestaurant = "Illegal Pete's";
        } else if(location.equals("29th Street")) {
            chosen = chipotle;
            chosenRestaurant = "Chipotle";
        } else if(location.equals("Pearl Street")) {
            chosen = bartaco;
            chosenRestaurant = "Bartaco";
        }

        suggest.setText("You should check out " + chosenRestaurant);



    }

    public void loadSite(String chosen) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(chosen));
        startActivity(intent);
    }




}
