package com.example.josecanizares.josefinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View.OnClickListener;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.ToggleButton;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Burrito");

        final EditText burritoName = (EditText) findViewById(R.id.burritoName);
        final RadioGroup radiogroup = (RadioGroup) findViewById(R.id.radioGroup);
        final ToggleButton veggieMeat = (ToggleButton) findViewById(R.id.veggieMeat);
        final CheckBox salsa = (CheckBox) findViewById(R.id.salsa);
        final CheckBox sour_cream = (CheckBox) findViewById(R.id.sour_cream);
        final CheckBox cheese = (CheckBox) findViewById(R.id.cheese);
        final CheckBox guacamole = (CheckBox) findViewById(R.id.guacamole);
        final Spinner locations = (Spinner) findViewById(R.id.spinner);
        final TextView description = (TextView) findViewById(R.id.description);
        final Switch s = (Switch) findViewById(R.id.glutenFree);
        Button findBurrito = (Button) findViewById(R.id.find_burrito);
        final ImageView img = (ImageView) findViewById(R.id.burritoView);
        Button build = (Button) findViewById(R.id.build);

        radiogroup.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                img.setVisibility(View.VISIBLE);
                if(checkedId == R.id.burrito) {
                    img.setImageResource(R.drawable.burrito);
                } else {
                    img.setImageResource(R.drawable.taco);
                }
            }
        });

        findBurrito.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                goToRestaurant(locations.getSelectedItem().toString());
            }
        });


        build.setOnClickListener( new OnClickListener() {
            public void onClick(View v) {
                String n = burritoName.getText().toString();

                boolean salsaBool = salsa.isChecked();
                boolean sour_creamBool = sour_cream.isChecked();
                boolean cheeseBool = cheese.isChecked();
                boolean guacamoleBool = guacamole.isChecked();

                boolean glutenBool = s.isChecked();

                String location = locations.getSelectedItem().toString();

                int selectedId = radiogroup.getCheckedRadioButtonId();
                boolean meatBool = veggieMeat.isChecked();

                img.setVisibility(View.VISIBLE);

                String withMeat = "";
                String withSalsa = "";
                String withSourCream = "";
                String withCheese = "";
                String withGuacamole = "";
                String type = "burrito ";

                if(selectedId == R.id.taco) {
                    type = "taco ";
                }

                String glutenText = "";
                if(meatBool) {
                    withMeat = "with meat ";
                } else {
                    withMeat = "without meat ";
                }
                if(salsaBool) {
                    withSalsa = "with salsa ";
                }
                if(sour_creamBool) {
                    withSourCream = "with sour cream ";
                }
                if(cheeseBool) {
                    withCheese = "with cheese ";
                }
                if(guacamoleBool) {
                    withGuacamole = "with guacamole ";
                }
                if(glutenBool) {
                    glutenText = "on a corn tortilla ";
                }



                description.setText("The " + n + " is a " + type + withMeat + withSalsa + withSourCream + withCheese + withGuacamole + glutenText + "you'd like to eat on " + location + ".");
            }
        });



    }

    public void goToRestaurant(String location) {
        Intent intent = new Intent(this, Restaurant.class);
        intent.putExtra("location", location);
        startActivity(intent);
    }


}
