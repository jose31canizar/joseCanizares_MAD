package com.example.josecanizares.scout;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.RatingBar;
import android.widget.TextView;

import org.apache.commons.lang3.text.WordUtils;

public class CoursePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_page);

        String courseYear = "";
        String averageGrade = "";
        String difficulty = "";

        Intent intent = getIntent();

        TextView courseNumber = (TextView) findViewById(R.id.courseNumber);
        TextView courseTitle = (TextView) findViewById(R.id.courseTitle);
        TextView courseSubject = (TextView) findViewById(R.id.courseSubject);
        TextView courseDifficulty = (TextView) findViewById(R.id.courseDifficulty);
        TextView courseInstructor = (TextView) findViewById(R.id.courseInstructor);
        TextView courseAverageGrade = (TextView) findViewById(R.id.courseAverageGrade);
        RatingBar ratingBar = (RatingBar) findViewById(R.id.ratingBar);
        TextView CourseYear = (TextView) findViewById(R.id.courseYear);

        Typeface avenir = Typeface.createFromAsset(getAssets(), "avenir.ttf");
        courseNumber.setTypeface(avenir);
        courseSubject.setTypeface(avenir);

        courseNumber.setText(intent.getStringExtra("course_number"));
        courseTitle.setText(intent.getStringExtra("course_title"));
        courseSubject.setText(intent.getStringExtra("course_subject"));

        difficulty = intent.getStringExtra("course_difficulty");
        int diff = (int) Double.parseDouble(difficulty);
        if(diff <= 6 ) {
            if (diff <= 1) {
                difficulty = "0 to 3 hours";
            } else if (diff <= 2) {
                difficulty = "4 to 6 hours";
            } else if (diff <= 3) {
                difficulty = "7 to 9 hours";
            } else if (diff <= 4) {
                difficulty = "10 to 12 hours";
            } else if (diff <= 5) {
                difficulty = "13 to 15 hours";
            } else if (diff <= 6) {
                difficulty = "16+ hours";
            } else {
                difficulty = "ridiculously hard";
            }
        } else {
            difficulty = "ridiculously hard";
        }

        courseDifficulty.setText(difficulty);
        courseInstructor.setText(WordUtils.capitalize(intent.getStringExtra("course_instructor").toLowerCase()));

        ratingBar.setRating(Float.valueOf(intent.getStringExtra("course_rating")));

        averageGrade = intent.getStringExtra("course_average_grade");

        int avg = (int) Double.parseDouble(averageGrade);

        if(avg <= 4) {
            averageGrade = "A";
        } else if (avg <= 3) {
            averageGrade = "B";
        } else if (avg <= 2) {
            averageGrade = "C";
        } else if (avg <= 1) {
            averageGrade = "D/F";
        } else {
            averageGrade = "D/F";
        }

        courseAverageGrade.setText(averageGrade);


        courseYear = intent.getStringExtra("course_year");

        if(courseYear.equals("20121")) {
            courseYear = "Spring 2012";
        } else if(courseYear.equals("20127")) {
            courseYear = "Fall 2012";
        } else if(courseYear.equals("20131")) {
            courseYear = "Spring 2013";
        } else if(courseYear.equals("20137")) {
            courseYear = "Fall 2013";
        } else if(courseYear.equals("20141")) {
            courseYear = "Spring 2014";
        } else if(courseYear.equals("20147")) {
            courseYear = "Fall 2014";
        } else if(courseYear.equals("20151")) {
            courseYear = "Spring 2015";
        } else if(courseYear.equals("20157")) {
            courseYear = "Fall 2015";
        } else if(courseYear.equals("20161")) {
            courseYear = "Spring 2016";
        } else if(courseYear.equals("20167")) {
            courseYear = "Fall 2016";
        } else if(courseYear.equals("20171")) {
            courseYear = "Spring 2017";
        } else if(courseYear.equals("20177")) {
            courseYear = "Spring 2017";
        } else {
            courseYear = "";
        }

        CourseYear.setText(courseYear);

    }
}
