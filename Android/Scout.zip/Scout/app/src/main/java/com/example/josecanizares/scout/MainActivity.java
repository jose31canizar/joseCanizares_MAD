package com.example.josecanizares.scout;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.lang.ref.Reference;
import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    private DatabaseReference mDatabase;
    private Query query;

//    @Override
//    protected void OnStart() {
//        FirebaseDatabase.getInstance().setPersistenceEnabled(true);
//    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FirebaseDatabase.getInstance().setPersistenceEnabled(true);
//        FirebaseDatabase.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();


        Button Search = (Button) findViewById(R.id.searchButton);
        Search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText searchCourseSubject = (EditText) findViewById(R.id.searchCourseSubject);
                EditText searchCourseNumber = (EditText) findViewById(R.id.searchCourseNumber);
                Spinner searchCourseYear = (Spinner) findViewById(R.id.searchCourseYear);

                final String courseSubject = searchCourseSubject.getText().toString();
                final String courseNumber = searchCourseNumber.getText().toString();
                final String courseYear = searchCourseYear.getSelectedItem().toString();

                if(courseSubject.equals("") && courseNumber.equals("")) {
                    //make toast
                    Context context = getApplicationContext();
                    CharSequence text = "Please search by subject, course number or both.";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                    return;
                } else {
                    goToCourse();
                }


            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();  // Always call the superclass method first
        ProgressBar spinner = (ProgressBar)findViewById(R.id.progressBar);
        spinner.setVisibility(View.GONE);

    }

    public void goToCourse() {
        ProgressBar spinner = (ProgressBar)findViewById(R.id.progressBar);
        spinner.setVisibility(View.VISIBLE);

        final List<String> numberList = new ArrayList<String>();
        final List<String> titleList = new ArrayList<String>();
        final List<String> subjectList = new ArrayList<String>();
        final List<String> difficultyList = new ArrayList<String>();
        final List<String> instructorList = new ArrayList<String>();
        final List<String> averageGradeList = new ArrayList<String>();
        final List<String> ratingList = new ArrayList<String>();
        final List<String> yearList = new ArrayList<>();

        EditText searchCourseSubject = (EditText) findViewById(R.id.searchCourseSubject);
        EditText searchCourseNumber = (EditText) findViewById(R.id.searchCourseNumber);
        Spinner searchCourseYear = (Spinner) findViewById(R.id.searchCourseYear);

        final String courseSubject = searchCourseSubject.getText().toString();
        final String courseNumber = searchCourseNumber.getText().toString();
        String courseYear = searchCourseYear.getSelectedItem().toString();



        if(courseYear.equals("Spring 2012")) {
            courseYear = "20121";
        } else if(courseYear.equals("Fall 2012")) {
            courseYear = "20127";
        } else if(courseYear.equals("Spring 2013")) {
            courseYear = "20131";
        } else if(courseYear.equals("Fall 2013")) {
            courseYear = "20137";
        } else if(courseYear.equals("Spring 2014")) {
            courseYear = "20141";
        } else if(courseYear.equals("Fall 2014")) {
            courseYear = "20147";
        } else if(courseYear.equals("Spring 2015")) {
            courseYear = "20151";
        } else if(courseYear.equals("Fall 2015")) {
            courseYear = "20157";
        } else if(courseYear.equals("Spring 2016")) {
            courseYear = "20161";
        } else if(courseYear.equals("Fall 2016")) {
            courseYear = "20167";
        } else if(courseYear.equals("Spring 2017")) {
            courseYear = "20171";
        } else if(courseYear.equals("Spring 2017")) {
            courseYear = "20177";
        } else {
            courseYear = "";
        }

        System.out.println(courseSubject);
        System.out.println(courseNumber);
        System.out.println(courseYear);
        System.out.println("finito");


        String strictFilter = "";
        String selectedField = "";
        String secondField = "";
        String thirdField = "";
        String secondFilter = "";
        String thirdFilter = "";
        Boolean cont = true;

        if (TextUtils.isEmpty(courseSubject) && TextUtils.isEmpty(courseNumber) && TextUtils.isEmpty(courseYear)) {
            System.out.println("You have not typed anything.");
            cont = false;
        } else if (TextUtils.isEmpty(courseSubject) && TextUtils.isEmpty(courseNumber)) {
            System.out.println("some 1.");
            strictFilter = courseYear;
            selectedField = "YearTerm";

        } else if (TextUtils.isEmpty(courseSubject) && TextUtils.isEmpty(courseYear)) {
            System.out.println("some 2.");
            strictFilter = courseNumber;
            selectedField = "Course";

        } else if (TextUtils.isEmpty(courseNumber) && TextUtils.isEmpty(courseYear)) {
            System.out.println("some 3.");
            strictFilter = courseSubject;
            selectedField = "Subject";

        } else if (TextUtils.isEmpty(courseSubject)) {
            System.out.println("some 4.");
            strictFilter = courseNumber;
            secondFilter = courseYear;
            selectedField = "Course";
            secondField = "YearTerm";

        } else if (TextUtils.isEmpty(courseNumber)) {
            System.out.println("some 5.");
            strictFilter = courseSubject;
            secondFilter = courseYear;
            selectedField = "Subject";
            secondField = "YearTerm";


        } else if (TextUtils.isEmpty(courseYear)) {
            System.out.println("some 6.");
            strictFilter = courseNumber;
            secondFilter = courseSubject;
            selectedField = "Course";
            secondField = "Subject";

        } else {
            System.out.println("some 7.");
            strictFilter = courseSubject;
            secondFilter = courseYear;
            thirdFilter = courseNumber;
            selectedField = "Subject";
            secondField = "YearTerm";
            thirdField = "Course";
        }

        if(cont) {
            query = mDatabase.orderByChild(selectedField).equalTo(strictFilter);
        }


        final String finalSecondField = secondField;
        final String finalThirdField = thirdField;
        final String finalSecondFilter = secondFilter;
        final String finalThirdFilter = thirdFilter;
        final String finalCourseYear = courseYear;
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                if (dataSnapshot.exists()) {
                    for (DataSnapshot issue : dataSnapshot.getChildren()) {
                        System.out.println(issue.child("Course").getValue());
                        System.out.println(finalSecondField);
                        System.out.println("end");
                        System.out.println(finalSecondFilter);
                        if(!TextUtils.isEmpty(finalSecondField)) {
                            System.out.println("first case");
                            System.out.println(issue.child(finalSecondField).getValue());
                            System.out.println(finalSecondFilter);
                            if(issue.child(finalSecondField).getValue().equals(finalSecondFilter)) {
                                if(!TextUtils.isEmpty(finalThirdField)) {
                                    System.out.println("third case");
                                    if(issue.child(finalThirdField).getValue().equals(finalThirdFilter)) {
                                        numberList.add((String) issue.child("Course").getValue());
                                        titleList.add((String) issue.child("CourseTitle").getValue());
                                        subjectList.add((String) issue.child("Subject").getValue());
                                        difficultyList.add((String) issue.child("Workload_Raw").getValue());
                                        instructorList.add((String) issue.child("insname1").getValue());
                                        averageGradeList.add((String) issue.child("AVG_GRD").getValue());
                                        ratingList.add((String) issue.child("AvgCourse").getValue());
                                        yearList.add((String) issue.child("YearTerm").getValue());
                                    }
                                } else {
                                    System.out.println("second case");
                                    numberList.add((String) issue.child("Course").getValue());
                                    titleList.add((String) issue.child("CourseTitle").getValue());
                                    subjectList.add((String) issue.child("Subject").getValue());
                                    difficultyList.add((String) issue.child("Workload_Raw").getValue());
                                    instructorList.add((String) issue.child("insname1").getValue());
                                    averageGradeList.add((String) issue.child("AVG_GRD").getValue());
                                    ratingList.add((String) issue.child("AvgCourse").getValue());
                                    yearList.add((String) issue.child("YearTerm").getValue());
                                }
                            }
                        } else {
                            System.out.println("fourth case");
                            numberList.add((String) issue.child("Course").getValue());
                            titleList.add((String) issue.child("CourseTitle").getValue());
                            subjectList.add((String) issue.child("Subject").getValue());
                            difficultyList.add((String) issue.child("Workload_Raw").getValue());
                            instructorList.add((String) issue.child("insname1").getValue());
                            averageGradeList.add((String) issue.child("AVG_GRD").getValue());
                            ratingList.add((String) issue.child("AvgCourse").getValue());
                            yearList.add((String) issue.child("YearTerm").getValue());
                        }
                    }
                }

                if(numberList.isEmpty()) {
                    System.out.println("no results");


                } else {


                    Intent intent = new Intent(MainActivity.this, SearchResults.class);
                    intent.putStringArrayListExtra("number_list", (ArrayList<String>) numberList);
                    intent.putStringArrayListExtra("title_list", (ArrayList<String>) titleList);
                    intent.putStringArrayListExtra("subject_list", (ArrayList<String>) subjectList);
                    intent.putStringArrayListExtra("difficulty_list", (ArrayList<String>) difficultyList);
                    intent.putStringArrayListExtra("instructor_list", (ArrayList<String>) instructorList);
                    intent.putStringArrayListExtra("average_grade_list", (ArrayList<String>) averageGradeList);
                    intent.putStringArrayListExtra("rating_list", (ArrayList<String>) ratingList);
                    intent.putStringArrayListExtra("year_list", (ArrayList<String>) yearList);
                    startActivity(intent);
                }



            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


    }


}
