package com.example.josecanizares.scout;

import java.util.HashMap;
import java.util.Map;

import javax.security.auth.Subject;

/**
 * Created by josecanizares on 11/30/17.
 */

public class Course {

    private String title;
    private String year;
    private String subject;
    private String courseNumber;
    private String courseTitle;
    private String level;
    private String hours;
    private String averageGrade;

    public String getTitle() {
        return title;
    }

    public String getYear() {
        return year;
    }

    public String getSubject() {
        return subject;
    }

    public String getCourseNumber() {
        return courseNumber;
    }

    public String getCourseTitle() {
        return courseTitle;
    }

    public String getLevel() {
        return level;
    }

    public String getHours() {
        return hours;
    }

    public String getAverageGrade() {
        return averageGrade;
    }

    public String getWorkload() {
        return workload;
    }

    public String getWorkloadHoursPerWeek() {
        return workloadHoursPerWeek;
    }

    public String getAverageCourse() {
        return AverageCourse;
    }

    public String getAverageInstructor() {
        return AverageInstructor;
    }

    public String getInstructorName() {
        return instructorName;
    }

    public String getSubjectLabel() {
        return subjectLabel;
    }

    private String workload;
    private String workloadHoursPerWeek;
    private String AverageCourse;
    private String AverageInstructor;
    private String instructorName;
    private String subjectLabel;

    public Course() {
        // Default constructor required for calls to DataSnapshot.getValue(Post.class)
    }

    public Course(String title, String year, String subject, String courseNumber, String courseTitle, String level, String hours, String averageGrade, String workload, String workloadHoursPerWeek, String averageCourse, String averageInstructor, String instructorName, String subjectLabel) {
        this.title = title;
        this.year = year;
        this.subject = subject;
        this.courseNumber = courseNumber;
        this.courseTitle = courseTitle;
        this.level = level;
        this.hours = hours;
        this.averageGrade = averageGrade;
        this.workload = workload;
        this.workloadHoursPerWeek = workloadHoursPerWeek;
        AverageCourse = averageCourse;
        AverageInstructor = averageInstructor;
        this.instructorName = instructorName;
        this.subjectLabel = subjectLabel;
    }

    public Course(String title) {
        this.title = title;
    }
}