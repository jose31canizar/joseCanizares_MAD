package com.example.josecanizares.scout;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import org.apache.commons.lang3.text.WordUtils;
import org.w3c.dom.Text;

import java.util.List;

public class SearchResults extends AppCompatActivity {

    private String[] numbers;
    private String[] titles;
    private String[] subjects;
    private String[] difficulties;
    private String[] instructors;
    private String[] averageGrades;
    private String[] ratings;
    private String[] years;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_results);
        intent = getIntent();


        List<String> numberList = intent.getStringArrayListExtra("number_list");
        List<String> titleList = intent.getStringArrayListExtra("title_list");
        List<String> subjectList = intent.getStringArrayListExtra("subject_list");
        List<String> difficultyList = intent.getStringArrayListExtra("difficulty_list");
        List<String> instructorList = intent.getStringArrayListExtra("instructor_list");
        List<String> averageGradeList = intent.getStringArrayListExtra("average_grade_list");
        List<String> ratingList = intent.getStringArrayListExtra("rating_list");
        List<String> yearList = intent.getStringArrayListExtra("year_list");
        numbers = new String[numberList.size()];
        numbers = numberList.toArray(numbers);
        Log.d("lemon", numbers[0]);
        titles = new String[numberList.size()];
        titles = titleList.toArray(titles);

        subjects = new String[numberList.size()];
        subjects = subjectList.toArray(subjects);

        difficulties = new String[numberList.size()];
        difficulties = difficultyList.toArray(difficulties);

        instructors = new String[numberList.size()];
        instructors = instructorList.toArray(instructors);

        averageGrades = new String[numberList.size()];
        averageGrades = averageGradeList.toArray(averageGrades);

        ratings = new String[numberList.size()];
        ratings = ratingList.toArray(ratings);

        years = new String[numberList.size()];
        years = yearList.toArray(years);


        createTableCell();
    }





    public void createTableCell(){
        TableLayout layout = (TableLayout) findViewById(R.id.tableLayout);



        for (int i = 0; i < numbers.length; i++) {
            TableRow row = new TableRow(this);

            Display display = getWindowManager().getDefaultDisplay();
            int width = display.getWidth();
            int height = display.getHeight();

            TableRow.LayoutParams params = new TableRow.LayoutParams((int)(width/1.25), TableRow.LayoutParams.WRAP_CONTENT);
            int leftMargin=100;
            int topMargin=100;
            int rightMargin=100;
            int bottomMargin=100;

            params.setMargins(leftMargin, topMargin, rightMargin, bottomMargin);



            TextView numberText = new TextView(this);
            TextView titleText = new TextView(this);
            TextView subjectText = new TextView(this);
            TextView instructorText = new TextView(this);

            LinearLayout description = new LinearLayout(this);
            description.setOrientation(LinearLayout.VERTICAL);

            numberText.setTextSize(15);
            titleText.setTextSize(15);
            subjectText.setTextSize(15);
            instructorText.setTextSize(15);

            numberText.setTextColor(Color.parseColor("#3B467A"));
            titleText.setTextColor(Color.parseColor("#888888"));
            subjectText.setTextColor(Color.parseColor("#888888"));
            instructorText.setTextColor(Color.parseColor("#888888"));

            Typeface avenir = Typeface.createFromAsset(getAssets(), "avenir.ttf");
            numberText.setTypeface(avenir);
            titleText.setTypeface(avenir);
            subjectText.setTypeface(avenir);
            instructorText.setTypeface(avenir);

            numberText.setText(WordUtils.capitalize(numbers[i].toLowerCase()));
            titleText.setText(titles[i]);
            subjectText.setText(subjects[i]);
            instructorText.setText(WordUtils.capitalize(instructors[i].toLowerCase()));

            subjectText.setTextSize(26);
            numberText.setTextSize(26);

            description.addView(subjectText);
            description.addView(numberText);
            description.addView(titleText);
            description.addView(instructorText);

            GradientDrawable shape =  new GradientDrawable();
            shape.setCornerRadius( 30 );
            shape.setColor(Color.parseColor("#f1f1f1"));


            row.addView(description);
            row.setBackground(shape);

            ImageView shoe = new ImageView(this);


            row.setPadding(10, 40, 10, 40);
            row.setLayoutParams(params);

            layout.addView(row, i);

            row.setOnClickListener(new RowOnClickListener(numbers[i], titles[i], subjects[i], difficulties[i], instructors[i], averageGrades[i], ratings[i], years[i]));
        }
    }

    public static int getImageId(Context context, String imageName) {
        return context.getResources().getIdentifier("drawable/" + imageName, null, context.getPackageName());
    }

    public void goToCourse(String number, String title, String subject, String difficulty, String instructor, String averageGrade, String rating, String year) {
        Intent intent = new Intent(this, CoursePage.class);
        intent.putExtra("course_number", number);
        intent.putExtra("course_title", title);
        intent.putExtra("course_subject", subject);
        intent.putExtra("course_difficulty", difficulty);
        intent.putExtra("course_instructor", instructor);
        intent.putExtra("course_average_grade", averageGrade);
        intent.putExtra("course_rating", rating);
        intent.putExtra("course_year", year);
        startActivity(intent);
    }

    public class RowOnClickListener implements View.OnClickListener
    {

        int index;
        String number;
        String title;
        String subject;
        String difficulty;
        String instructor;
        String averageGrade;
        String rating;
        String year;

        public RowOnClickListener(String number,  String title, String subject, String difficulty, String instructor, String averageGrade, String rating, String year) {
            this.number = number;
            this.title = title;
            this.subject = subject;
            this.difficulty = difficulty;
            this.instructor = instructor;
            this.averageGrade = averageGrade;
            this.rating = rating;
            this.year = year;
        }



        @Override
        public void onClick(View v)
        {
            goToCourse(this.number, this.title, this.subject, this.difficulty, this.instructor, this.averageGrade, this.rating, this.year);
            return;
        }

    };
}
